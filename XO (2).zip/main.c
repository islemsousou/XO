#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <windows.h>
#define taille 3


void jouerSon(const char *fichier) {
    PlaySound(fichier, NULL, SND_FILENAME | SND_ASYNC);
}

void setColorFull(int couleurTexte) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, couleurTexte);
}

void welcome (){
    setColorFull(14);

printf("                                      WELCOME TO THE GAME !!!!\n");
printf("                                      *********X O*********\n");
printf("                                      les case sont numerote de 1 a 9 \n");
printf("                                      choisir le numero de case for play\n");
printf("                                      si vous choisie une case deja occupee vous perd directement votre tour\n");
}



void Choisir_ModeJeu(int *mode,int *level){
 do {
  setColorFull(9 );
        printf("                              quelle mode de jeu vous pfererez : \n");
        printf("                                   1. contre un Joueur\n");
        printf("                                   2. contre un Ordinateur\n");
        printf(" mode 1 ou 2 -->  \t");
        scanf("%d", mode);
        if(*mode != 1 && *mode != 2)
            {
            printf("reesayer votre choix svp!!\n");
        }
    } while(*mode != 1 && *mode != 2);
 if (*mode==2){
        do{
               setColorFull(10);
    printf("                   1- un niveau avance \n");
    printf("                   2- un niveau simple \n");
    scanf("%d",level);
     if(*level != 1 && *level != 2)
            {
            printf("reesayer votre choix svp!!\n");
        }
        }while(*level !=1 && *level != 2);
 }
}

void basic_board(char (*board)[taille]) {
    int i , j;
    for(i = 0 ; i < taille; i++ )
        {
        for ( j =0 ; j< taille ; j++)
        {
            board[i][j] = ' ';
              // pour initialiser un espace vide a chaque case
    }
     }
      }

void board_Numerote(char (*board)[taille]) {
     printf("\n");
    int i , j;
   setColorFull(3);
    for( i = 0; i < taille; i++)
        {
            for (j = 0 ; j < taille ; j++)
            {
            char c = board[i][j];  // c represente le contenue de la case
            if(c == ' ')
                {
                printf(" %d ", i * 3 + j + 1);   // pour ajuster les nombres du case de 1 a 9
                }
             else
             {
                 setColorFull(6);
                printf(" %c ", c);   // si la case n'est pas vide afficher leur continue (X O)
             }
             if(j != taille-1) // pour cree un separateur entre les colones ( -1 pour qu'il ne s'affiche pas apres la dernier colone)
             {
                 setColorFull(8);
                printf("|");
             }
        }
        printf("\n");
        if(i != taille-1)  // pour cree un separateur entre les lignes ( -1 pour qu'il ne s'affiche pas apres la dernier ligne)
        setColorFull(8);
            printf("\n-----------\n");
}
         }

void choix_Val(char board[taille][taille], int caseNum, bool *valide) {
    *valide = true; //initialiser la situation comme une situation validee
    if(caseNum < 1 || caseNum > 9)
        {
        *valide = false;  //case n'exsiste pas
        return;
    }
    int ligne = (caseNum - 1) / taille; // convertir le numero saisi pour savoir a quel ligne on met le symbole (X/O)
    int colonne = (caseNum - 1) % taille;   //convertir le numero saisi pour savoir a quel colone on met le symbole (X/O)
    if(board[ligne][colonne] != ' ')
        {
        *valide = false; // case deja occupee
    }
}

void Faire_Mouvement(char (*board)[taille], int caseNum, char joueur) {
    int ligne = (caseNum - 1) / taille;
    int colonne = (caseNum - 1) % taille;
   board[ligne][colonne] = joueur;
}

bool Gagnant(char (*board)[taille], char joueur) {
    for(int i = 0; i < taille; i++)
        {
        // verifier les ligne et les colones
        if((board[i][0] == joueur && board[i][1] == joueur && board[i][2] == joueur)
        ||(board[0][i] == joueur && board[1][i] == joueur && board[2][i] == joueur))
            return true;
    // verifier les diagonales
    if((board[0][0] == joueur && board[1][1] == joueur && board[2][2] == joueur)
       ||(board[0][2] == joueur && board[1][1] == joueur && board[2][0] == joueur))
        return true;
    }
    return false;
}

bool Match_Nul(char (*board)[taille]) {
    int i ,j ;
    for(i = 0 ; i < taille ; i++ ) {
            for (j = 0 ; j < taille ; j++){
            if(board[i][j] == ' ')
                return false;
        }
    }
    return true;   // la condition est verifier si tous les cases sont rempli et la condition gagnant n'est pas verifier
}

void Tour_Joueur(char (*board)[taille], char joueur) {
    int caseNum;
    bool valide;
    do {
            setColorFull(13);
        printf("Joueur %c, entrer une case (1-9): ", joueur);
         scanf("%d", &caseNum);
    } while(caseNum<1 || caseNum>9);
        choix_Val(board, caseNum, &valide); //pour verifier si le mouvement est valide ou pas
        if(!valide)
            {
                setColorFull(4);
            printf("Case deja occupee vous avez perdu votre tour \n");
            exit(0);
        }
    Faire_Mouvement(board, caseNum, joueur);// si le mouvement est valide on appel cette fonction pour le jerer

    }

bool Mouv_Gagnant(char board[3][3], char joueur, int *caseNum) {
    for (int i = 1; i <= 9; i++) {
        bool valide;
        choix_Val(board, i, &valide);
        if (valide) {
            board[(i - 1) / 3][(i - 1) % 3] = joueur;
            if (Gagnant(board, joueur)) {
                *caseNum = i;
                board[(i - 1) / 3][(i - 1) % 3] = ' ';
                return true;
            }
            board[(i - 1) / 3][(i - 1) % 3] = ' ';
        }
    }
    return false;
}

void Tour_Ordinateur_hard(char (*board)[taille], char joueur) {

     int caseNum;
    char adversaire = 'X'; // c'est le cas  contraire de l'ordinateur

    if (Mouv_Gagnant(board, joueur, &caseNum)) //pour verifier si l'ordinateur peut gagner
        {
        Faire_Mouvement(board, caseNum, joueur);
        return;
    }

    if (Mouv_Gagnant(board, adversaire, &caseNum))// on verifier si l'autre joueur peut gagner au prochaine tour , il le bloque
        {
        Faire_Mouvement(board, caseNum, joueur);
        return;
    }

    do {
        caseNum = rand() % 9 + 1;   // sinon on choisit une case de maniere al�atoire
        bool valide;
        choix_Val(board, caseNum, &valide);
        if (valide) break;  // si le choix de l'ord est valid�e en sort de la boucle sinon il recommence a choisir une autre case
    } while (true);

    Faire_Mouvement(board, caseNum, joueur);
}

 void tour_Ordinateur_sinor(char (*board)[taille], char joueur) {
     int caseNum;
     setColorFull(13 );
    printf("Tour de l'ordinateur (%c)...\n", joueur);

    bool valide ;
    do {
        caseNum = rand() % 9 + 1;
         choix_Val(board, caseNum , &valide);
    } while(!valide );
    Faire_Mouvement(board, caseNum, joueur);
}

void Jouer_Partie() {
    char board[taille][taille];
    int mode;
    int level;
     int ptX=0;
    int ptO=0;
    char joueur = 'X';  // on commence toujours par X
   Choisir_ModeJeu(&mode,&level);

    basic_board(board);
    bool jeuTermine = false; // booleen pour verifier si le jeux a terminer ou pas encore
       while(!jeuTermine) {
    board_Numerote(board);

    // Tour du joueur actuel (X ou O)
   if(mode == 1) {
    Tour_Joueur(board, joueur);  // X et O sont humains
}
else if (mode == 2 && joueur == 'X') {
    Tour_Joueur(board, joueur);  // X est humain
}
else if (mode == 2 && joueur == 'O') {
    if(level == 1)
        Tour_Ordinateur_hard(board, joueur);
    else if(level == 2)
        tour_Ordinateur_sinor(board, joueur);
}


    // V�rifier si le joueur actuel a gagn�
    if(Gagnant(board, joueur)) {
        board_Numerote(board);
        if(mode == 1 || joueur == 'X') {
              setColorFull(5 );
            printf("Le joueur %c a gagne!\n", joueur);
            ptX++;
        }
        else {
            setColorFull(5);
            printf("L'ordinateur a gagne!\n");
            ptO++;
        }
       setColorFull(12 );
        printf("Score: X = %d | O = %d\n", ptX, ptO);
        jeuTermine = true; // On arr�te la partie
    }
    // V�rifier si match nul
    else if(Match_Nul(board)) {
        board_Numerote(board);
        setColorFull(5 );
        printf("Match nul!\n");
        setColorFull(12);
        printf("Score: X = %d | O = %d\n", ptX, ptO);
        jeuTermine = true; // On arr�te la partie
    }
    // CHANGEMENT DE TOUR SEULEMENT SI LA PARTIE CONTINUE
    else
        joueur = (joueur == 'X') ? 'O' : 'X'; // Passer � l'autre joueur

}

}

int main() {
    welcome ();
    int mode;

    int choix;
do{
   setColorFull(3 );
        printf("1_vous voulez : \n");
        printf("1_commencer un nouveau tours\n");
        printf("2_ Quiter\n");
        scanf("%d",&choix);
        system("cls");
 jouerSon("debut.wav");
        switch(choix) {
            case 1:
                Jouer_Partie();
                break;
            case 2:
                setColorFull(10 );
                printf("BAY BAY!\n");
                break;
            default:
                setColorFull( 14);
                printf("veuillez choisir entre les choix proposee svp !!\n");
        }
        jouerSon("fin.wav");
    }  while(choix != 2);

    return 0;
}



